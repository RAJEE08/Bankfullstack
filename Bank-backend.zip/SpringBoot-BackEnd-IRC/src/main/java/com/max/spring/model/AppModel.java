package com.max.spring.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="bank")
public class AppModel {

	@Id
	// ID Auto generated 
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long customer_id;
	private String customer_name;
	private int account_no;
	private int account_balance;
	private String account_type;
	private long phone_no;
	
	
	
	public AppModel() {
		super();
	}
	public AppModel(long customer_id, String customer_name, int account_no, int account_balance, String account_type,
			long phone_no) {
		super();
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.account_no = account_no;
		this.account_balance = account_balance;
		this.account_type = account_type;
		this.phone_no = phone_no;
	}
	// Getters and Setters for fields
	
	public long getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(long customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public int getAccount_no() {
		return account_no;
	}
	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}
	public int getAccount_balance() {
		return account_balance;
	}
	public void setAccount_balance(int account_balance) {
		this.account_balance = account_balance;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public long getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}
	@Override
	public String toString() {
		return "AppModel [customer_id=" + customer_id + ", customer_name=" + customer_name + ", account_no="
				+ account_no + ", account_balance=" + account_balance + ", account_type=" + account_type + ", phone_no="
				+ phone_no + "]";
	}
	
	
	
	
	
}
