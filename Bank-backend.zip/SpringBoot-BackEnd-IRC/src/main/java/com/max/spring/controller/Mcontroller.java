package com.max.spring.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.max.spring.model.AppModel;
import com.max.spring.model.AuthModel;
import com.max.spring.service.Mservice;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class Mcontroller {
	@Autowired
	private Mservice service;

	@Tag(name = "Signin", description = "Login Endpoint")
	@PostMapping("/Signin")
	private String Login(@RequestBody Map<String, String> xLogin) {
	    String username = xLogin.get("username");
	    String password = xLogin.get("password");
	    String result = service.Login(username, password);
	    return result;
	}

	@Tag(name = "Signup", description = "Signup Endpoint")
    @PostMapping("/Signup")
    public String Signup(@RequestBody AuthModel user) {
        return service.Signup(user);
    }
	
	@Tag(name = "List Customer", description = "List All Customers")
	@GetMapping("/list")
	private List<AppModel> Customer(){
		return service.getData();
	}
	
	@Tag(name = "Sort Customer by ID", description = "View indudual Customer Data")
	@GetMapping("/view/{id}")
	private Optional<AppModel> viewCustomer(@PathVariable Long id) {
		return service.findbyID(id);
	}
			
	@Tag(name = "Add Customer", description = "Add New Customer")
	@PostMapping("/add")
	private AppModel addCustomert(@RequestBody AppModel data) {
		return service.addData(data);
	}
	
	@Tag(name = "Edit Customer", description = "Edit Existing Customer")
	@PutMapping("/edit/{id}")
	private AppModel editCustomer(@PathVariable Long id, @RequestBody AppModel data) {
		return service.editData(data, id);
	}
	
	@Tag(name = "Delete Data", description = "Delete The Existing Customer")
	@DeleteMapping("/delete/{id}")
	private String deleteCustomer(@PathVariable Long id) {
		return service.deleteData(id);
	}
}
